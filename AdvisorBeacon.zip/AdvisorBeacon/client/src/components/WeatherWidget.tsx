import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Cloud, 
  Sun, 
  CloudRain, 
  CloudSnow, 
  Zap,
  Eye,
  Wind,
  Droplets,
  Thermometer,
  Gauge
} from "lucide-react";

interface WeatherData {
  current: {
    name: string;
    main: {
      temp: number;
      feels_like: number;
      humidity: number;
      pressure: number;
    };
    weather: Array<{
      main: string;
      description: string;
      icon: string;
    }>;
    wind: {
      speed: number;
      deg: number;
    };
    visibility: number;
  };
  forecast: {
    list: Array<{
      dt: number;
      main: {
        temp: number;
        humidity: number;
      };
      weather: Array<{
        main: string;
        description: string;
        icon: string;
      }>;
      dt_txt: string;
    }>;
  };
}

const getWeatherIcon = (weatherMain: string, size: number = 24) => {
  const iconProps = { size, className: "text-primary" };
  
  switch (weatherMain.toLowerCase()) {
    case 'clear':
      return <Sun {...iconProps} className="text-yellow-500" />;
    case 'clouds':
      return <Cloud {...iconProps} className="text-gray-500" />;
    case 'rain':
    case 'drizzle':
      return <CloudRain {...iconProps} className="text-blue-500" />;
    case 'snow':
      return <CloudSnow {...iconProps} className="text-blue-200" />;
    case 'thunderstorm':
      return <Zap {...iconProps} className="text-purple-500" />;
    default:
      return <Cloud {...iconProps} />;
  }
};

const formatTime = (dt: number) => {
  return new Date(dt * 1000).toLocaleTimeString('vi-VN', {
    hour: '2-digit',
    minute: '2-digit'
  });
};

const formatDate = (dt: number) => {
  return new Date(dt * 1000).toLocaleDateString('vi-VN', {
    weekday: 'short',
    month: 'numeric',
    day: 'numeric'
  });
};

export function WeatherWidget() {
  const [location, setLocation] = useState<{lat: number, lon: number} | null>(null);
  
  useEffect(() => {
    // Get user's location - for Vietnam, we'll use Hanoi as default
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lon: position.coords.longitude
          });
        },
        () => {
          // Default to Hanoi, Vietnam if location access is denied
          setLocation({ lat: 21.0285, lon: 105.8542 });
        }
      );
    } else {
      // Default to Hanoi, Vietnam
      setLocation({ lat: 21.0285, lon: 105.8542 });
    }
  }, []);

  const { data: weatherData, isLoading, error } = useQuery<WeatherData>({
    queryKey: ['/api/weather', location?.lat, location?.lon],
    enabled: !!location,
  });

  if (isLoading || !location) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5" />
            Thông tin thời tiết
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-6 w-3/4" />
            <div className="grid grid-cols-2 gap-4">
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5" />
            Thông tin thời tiết
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Không thể tải dữ liệu thời tiết</p>
        </CardContent>
      </Card>
    );
  }

  if (!weatherData) return null;

  const { current, forecast } = weatherData;
  const todayForecast = forecast.list.slice(0, 4); // Next 4 time periods

  return (
    <div className="space-y-4">
      {/* Current Weather */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Cloud className="h-5 w-5" />
              Thời tiết hiện tại
            </div>
            <Badge variant="outline">{current.name}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              {getWeatherIcon(current.weather[0].main, 48)}
              <div>
                <div className="text-3xl font-bold">
                  {Math.round(current.main.temp)}°C
                </div>
                <div className="text-muted-foreground capitalize">
                  {current.weather[0].description}
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-muted-foreground">Cảm giác như</div>
              <div className="text-lg font-semibold">
                {Math.round(current.main.feels_like)}°C
              </div>
            </div>
          </div>

          {/* Weather Details */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-2">
              <Droplets className="h-4 w-4 text-blue-500" />
              <div>
                <div className="text-sm text-muted-foreground">Độ ẩm</div>
                <div className="font-semibold">{current.main.humidity}%</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Wind className="h-4 w-4 text-gray-500" />
              <div>
                <div className="text-sm text-muted-foreground">Gió</div>
                <div className="font-semibold">{current.wind.speed} m/s</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Gauge className="h-4 w-4 text-purple-500" />
              <div>
                <div className="text-sm text-muted-foreground">Áp suất</div>
                <div className="font-semibold">{current.main.pressure} hPa</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Eye className="h-4 w-4 text-green-500" />
              <div>
                <div className="text-sm text-muted-foreground">Tầm nhìn</div>
                <div className="font-semibold">{(current.visibility / 1000).toFixed(1)} km</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Forecast */}
      <Card>
        <CardHeader>
          <CardTitle>Dự báo thời tiết</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {todayForecast.map((item, index) => (
              <div key={index} className="text-center p-3 rounded-lg bg-muted/50">
                <div className="text-sm text-muted-foreground mb-2">
                  {formatTime(item.dt)}
                </div>
                <div className="flex justify-center mb-2">
                  {getWeatherIcon(item.weather[0].main, 24)}
                </div>
                <div className="font-semibold">
                  {Math.round(item.main.temp)}°C
                </div>
                <div className="text-xs text-muted-foreground capitalize">
                  {item.weather[0].description}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}