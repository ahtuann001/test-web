import AppSidebar from '../AppSidebar';

export default function AppSidebarExample() {
  return <AppSidebar />;
}