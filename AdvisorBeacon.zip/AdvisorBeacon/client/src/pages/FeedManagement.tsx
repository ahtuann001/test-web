import FeedManagementExample from "@/components/examples/FeedManagement";

export default function FeedManagementPage() {
  return <FeedManagementExample />;
}