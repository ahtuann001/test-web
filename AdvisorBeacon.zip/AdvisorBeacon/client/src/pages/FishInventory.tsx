import FishInventoryExample from "@/components/examples/FishInventory";

export default function FishInventoryPage() {
  return <FishInventoryExample />;
}