import DashboardOverview from "@/components/examples/DashboardOverview";

export default function Home() {
  return <DashboardOverview />;
}