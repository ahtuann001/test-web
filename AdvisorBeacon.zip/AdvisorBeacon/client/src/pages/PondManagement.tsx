import PondManagementExample from "@/components/examples/PondManagement";

export default function PondManagementPage() {
  return <PondManagementExample />;
}