import WaterQualityMonitorExample from "@/components/examples/WaterQualityMonitor";

export default function WaterQualityPage() {
  return <WaterQualityMonitorExample />;
}